# Positioning

## Working Name

Agent CEO Runbook Kit

## One-Liner

A practical operating kit for keeping autonomous AI agents useful, bounded, and accountable between human check-ins.

## Primary Audience

Solo builders and technical operators already using coding agents who want the agent to run a project, not just complete isolated coding tasks.

## Problem

Long-running AI agents tend to drift into fake progress: rewriting docs, tweaking pages, or continuing work after the next real step requires data or owner action.

## Promise

This kit gives the agent a project operating loop, stop rules, sub-agent briefs, decision gates, and owner-action tracking.

## What It Includes

- CEO agent prompt template
- Sub-agent delegation briefs
- Decision gates
- Owner-action board format
- Measurement template
- Example folder structure

## What It Does Not Promise

- No guarantee of unattended profit.
- No legal, tax, payment, or identity automation.
- No external account publishing without approval.
- No replacement for real market data.

## Primary CTA

Download the runbook kit.

## Secondary CTA

Read the operating model.

