# Product Hunt Draft

## Tagline

Keep autonomous AI agents useful between human check-ins.

## Description

Agent CEO Runbook Kit is a practical operating kit for solo builders running local AI agents on business or product work. It includes a CEO-agent prompt, sub-agent delegation briefs, stop rules, decision gates, and owner-action tracking so the agent knows when to keep working and when to wait for real data.

## First Comment Draft

I built this after running into a repeated problem with autonomous agents: they can keep moving, but not every movement creates useful evidence.

This kit is a small operating system for local agent work:

- CEO-agent prompt template
- Bounded run protocol
- Sub-agent briefs
- Stop rules
- Decision gates
- Owner-action tracking

The goal is not to make an agent "fully automatic." The goal is to keep it productive until the next real blocker is data, account access, payment setup, or a human decision.

I am testing whether other builders have this same operating problem.

## Launch Checklist

- Confirm public page URL.
- Confirm downloadable kit is accessible.
- Confirm no private credentials or internal project details are included.
- Confirm Product Hunt account is owner-approved.
- Publish only after owner approval.

