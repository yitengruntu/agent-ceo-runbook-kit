# Channel Plan

## First Test Channel

Use a community/Product Hunt style launch, not SEO.

## First CTA

Primary CTA: download the runbook kit.

Secondary CTA: reply/comment with the agent setup problem the user is trying to solve.

## Why Not Paid First

The first goal is to test whether the operating problem is real and whether builders understand the promise. Payment can be added after there is proof of demand.

## Candidate Launch Routes

1. Public GitHub release with downloadable ZIP.
2. Lightweight public page with direct ZIP download.
3. Product Hunt launch pointing at the public page or GitHub release.
4. One approved community post pointing at the same page.

## Owner Approval Needed

- Which public account/channel to use.
- Whether a public GitHub repo is acceptable.
- Whether to collect email before download.
- Whether the agent can post the Product Hunt/community copy.

## Measurement Window

Review 72 hours after launch:

- Qualified external visits
- ZIP downloads or access requests
- Comments/replies
- Direct setup questions
- Requests for a paid version or local tool

