# Agent CEO Runbook Kit

Version: 0.1

Start with:
- kit/00-start-here.md
- kit/01-ceo-agent-prompt.md

This is a practical operating kit for keeping autonomous AI agents useful, bounded, and accountable between human check-ins.

It does not automate payment, identity, tax, or external publishing decisions.
